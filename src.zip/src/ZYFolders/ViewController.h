//
//  ViewController.h
//  ZYFolders
//
//  Created by zhiyu on 13-5-6.
//  Copyright (c) 2013年 Zhiyu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZYFolders.h"

@interface ViewController : UIViewController

@property(nonatomic, retain) ZYFolders *folders;

@end
